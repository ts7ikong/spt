import {BasicColumn} from '/@/components/Table';
import {FormSchema} from '/@/components/Table';
import { rules} from '/@/utils/helper/validator';
import { render } from '/@/utils/common/renderUtils';
import { getWeekMonthQuarterYear } from '/@/utils';
//列表数据
export const columns: BasicColumn[] = [
   {
    title: '企业编码',
    align:"center",
    dataIndex: 'companyCode_dictText'
   },
   {
    title: '所属区县编码',
    align:"center",
    dataIndex: 'countycode'
   },
   {
    title: '区县名称',
    align:"center",
    dataIndex: 'countryname'
   },
   {
    title: '离线状态',
    align:"center",
    dataIndex: 'offlineState_dictText'
   },
   {
    title: '最新数据上报时间',
    align:"center",
    dataIndex: 'pushTime'
   },
];
//查询数据
export const searchFormSchema: FormSchema[] = [
	{
      label: "企业编码",
      field: 'companyCode',
      component: 'JSelectMultiple',
      componentProps:{
      },
      //colProps: {span: 6},
 	},
	{
      label: "所属区县编码",
      field: 'countycode',
      component: 'Input',
      //colProps: {span: 6},
 	},
	{
      label: "离线状态",
      field: 'offlineState',
      component: 'JSelectMultiple',
      componentProps:{
          dictCode:"rydwlxzt"
      },
      //colProps: {span: 6},
 	},
];
//表单数据
export const formSchema: FormSchema[] = [
  {
    label: '企业编码',
    field: 'companyCode',
    component: 'JDictSelectTag',
    componentProps:{
        dictCode:""
     },
  },
  {
    label: '所属区县编码',
    field: 'countycode',
    component: 'Input',
  },
  {
    label: '区县名称',
    field: 'countryname',
    component: 'Input',
    dynamicRules: ({model,schema}) => {
          return [
                 { required: true, message: '请输入区县名称!'},
          ];
     },
  },
  {
    label: '离线状态',
    field: 'offlineState',
    component: 'JDictSelectTag',
    componentProps:{
        dictCode:"rydwlxzt"
     },
  },
  {
    label: '最新数据上报时间',
    field: 'pushTime',
    component: 'Input',
  },
	// TODO 主键隐藏字段，目前写死为ID
	{
	  label: '',
	  field: 'id',
	  component: 'Input',
	  show: false
	},
];

// 高级查询数据
export const superQuerySchema = {
  companyCode: {title: '企业编码',order: 0,view: 'list', type: 'string',dictCode: '',},
  countycode: {title: '所属区县编码',order: 1,view: 'text', type: 'string',},
  countryname: {title: '区县名称',order: 2,view: 'text', type: 'string',},
  offlineState: {title: '离线状态',order: 3,view: 'list', type: 'string',dictCode: 'rydwlxzt',},
  pushTime: {title: '最新数据上报时间',order: 4,view: 'text', type: 'string',},
};

/**
* 流程表单调用这个方法获取formSchema
* @param param
*/
export function getBpmFormSchema(_formData): FormSchema[]{
  // 默认和原始表单保持一致 如果流程中配置了权限数据，这里需要单独处理formSchema
  return formSchema;
}